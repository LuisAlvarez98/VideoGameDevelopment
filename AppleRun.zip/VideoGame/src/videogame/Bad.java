package videogame;

import java.awt.Graphics;
import java.awt.Rectangle;
/**
 * Assets Class
 * @author Luis Felipe Alvarez Sanchez A01194173
 * 12 Feb 2019
 */
public class Bad extends Item{
    //Instance variables
    private int direction;
    private int width;
    private int height;
    private int speed;
    private Game game;
    /**
     * Bad constructor
     * @param x
     * @param y
     * @param direction
     * @param width
     * @param height
     * @param game 
     */
    public Bad(int x, int y, int direction, int width, int height, Game game) {
        super(x, y);
        this.direction = direction;
        this.width = width;
        this.height = height;
        this.game = game;
        this.speed = 1;
    }
    /**
     * increment speed by one
     */
    public void incrementSpeed(){
        this.speed+=1;
    }
    /**
     * getSpeed method
     * @return speed
     */
    public int getSpeed(){
        return speed;
    }
    /**
     * getWidth method
     * @return width
     */
    public int getWidth() {
        return width;
    }
    /**
     * getHeight method
     * @return height
     */
    public int getHeight() {
        return height;
    }
    /**
     * setWidth method
     * @param width 
     */
    public void setWidth(int width) {
        this.width = width;
    }
    /**
     * setHeight method
     * @param height 
     */
    public void setHeight(int height) {
        this.height = height;
    }
    /**
     * tick  method overall movement of apple
     */
    @Override
    public void tick() {
        //move the apple
          setY(getY() + getSpeed());
        // reset x position and y position if colision
        if (getX() <= -50) {
            setX(-50);
        }
        if (getY() + 50 >= game.getHeight()) {
            setY(game.getHeight() - 50);
        }
    }
    /**
     * creates the rectangle for the apple [collision purpose]
     * @return rectangle
     */
    public Rectangle getPerimetro() {

                return new Rectangle(getX(),getY() +45, 20, 10);
    }
     /**
      * render method
      * @param g 
      */
    @Override
    public void render(Graphics g) {
        //render the apple
        g.drawImage(Assets.apple, getX(), getY(), getWidth(), getHeight(), null);
    }
}
