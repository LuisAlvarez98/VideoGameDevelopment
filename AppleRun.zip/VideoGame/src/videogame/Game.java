package videogame;

import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.LinkedList;
/**
 * Game Class
 * @author Luis Felipe Alvarez Sanchez A01194173
 * 12 Feb 2019
 */
public class Game implements Runnable {
    private BufferStrategy bs;      // to have several buffers when displaying
    private Graphics g;             // to paint objects
    private Display display;        // to display in the game
    String title;                   // title of the window
    private int width;              // width of the window
    private int height;             // height of the window
    private Thread thread;          // thread to create the game
    private boolean running;        // to set the game
    private Player player;            // to use a player
    private Bad bad;                //to use a bad guy
    private LinkedList<Bad> bads;       //to use bad guys
    private KeyManager keyManager;  // to manage the keyboard
    private MouseManager mouseManager; // to manage the mouse
    private int score; // to manage score
    private int appleCounter; //to manage apple count
    private boolean gameover; // to manage gameover
    
    /**
     * to create title, width and height and set the game is still not running
     * @param title to set the title of the window
     * @param width to set the width of the window
     * @param height  to set the height of the window
     */
    public Game(String title, int width, int height) {
        this.title = title;
        this.width = width;
        this.height = height;
        running = false;
        keyManager = new KeyManager();
        mouseManager = new MouseManager();
        bads = new LinkedList<Bad>();
        this.score = 0;
        this.appleCounter = 0;
        this.gameover = false;
    }
    /**
     * increaseScore method: increases score by 100
     */
    public void increaseScore(){
        this.score += 100;
    }
    /**
     * decreaseScore method: decreases score by 20
     */
    public void decreaseScore(){
        this.score -= 20;
    }
    /**
     * getScore method
     * @return score
     */
    public int getScore(){
        return score;
    }
    /**
     * isGameOver method
     * @return gameover
     */
    public boolean isGameOver(){
        return gameover;
    }
    /**
     * setGameOver method
     * @param g 
     */
    public void setGameOver(boolean g){
        this.gameover = g;
    }
    /**
     * To get the width of the game window
     * @return an <code>int</code> value with the width
     */
    public int getWidth() {
        return width;
    }

    /**
     * To get the height of the game window
     * @return an <code>int</code> value with the height
     */
    public int getHeight() {
        return height;
    }
    
    /**
     * initializing the display window of the game
     */
    private void init() {
         display = new Display(title, getWidth(), getHeight());  
         Assets.init();
         //creates player
         player = new Player(0, getHeight() + getHeight(), 1, 100, 100, this);
         //apples size
         int iNum = (int)(Math.random() * 1 + 5);
         //create n enemies
         for(int i = 1; i <= iNum; i++){
             //random x and y pos
              int iPosX = (int)(Math.random() * getWidth() - 20);
              int iPosY = (int)(Math.random() * getHeight() * 0.5d * 0.2d - 70);
              bads.add( new Bad(iPosX, iPosY, 1, 50, 50, this));
         }
         //display: add listeners
         display.getJframe().addKeyListener(keyManager);
         display.getJframe().addMouseListener(mouseManager);
         display.getJframe().addMouseMotionListener(mouseManager);
         display.getCanvas().addMouseListener(mouseManager);
         display.getCanvas().addMouseMotionListener(mouseManager);
    }
    /**
     * run method
     */
    @Override
    public void run() {
        init();
        // frames per second
        int fps = 50;
        // time for each tick in nano segs
        double timeTick = 1000000000 / fps;
        // initializing delta
        double delta = 0;
        // define now to use inside the loop
        long now;
        // initializing last time to the computer time in nanosecs
        long lastTime = System.nanoTime();
        while (running) {
            // setting the time now to the actual time
            now = System.nanoTime();
            // acumulating to delta the difference between times in timeTick units
            delta += (now - lastTime) / timeTick;
            // updating the last time
            lastTime = now;
            
            // if delta is positive we tick the game
            if (delta >= 1) {
                tick();
                render();
                delta --;
            }
        }
        stop();
    }
    /**
     * getAppleCounter method
     * @return appleCounter
     */
    public int getAppleCounter(){
        return this.appleCounter;
    }
    /**
     * setAppleCounter method
     * @param appleCounter 
     */
    public void setAppleCounter(int appleCounter){
        this.appleCounter = appleCounter;
    }
    /**
     * getKeyManager method
     * @return keyManager
     */
    public KeyManager getKeyManager() {
        return keyManager;
    }
    /**
     * getMouseManager method
     * @return mouseManager
     */
    public MouseManager getMouseManager() {
        return mouseManager;
    }
    /**
     * tick method: main game loop
     */
    private void tick() {
        //checks if gameover
       if(!isGameOver()){
         keyManager.tick();
        // ticks player
        player.tick();
        //ticking the apples
        for(int i = 0; i <bads.size();i++){
            Bad bad = bads.get(i);
            bad.tick();
                //Player intersect apple
                if(player.intersecta(bad)) {
                  //If player touches apple a sound will play
                  Assets.punch.play();
                  //Set x and y pos randomly
                  int iPosX = (int)(Math.random() * getWidth() - 20);
                  int iPosY = (int)(Math.random() * getHeight() * 0.5d * 0.2d - 70);
                  bad.setX(iPosX);
                  bad.setY(iPosY);
                   //Increases score by 100
                  increaseScore();
                }
               //Apple intersect floor
               if (bad.getY() + 50 >= getHeight()) {
                   //If apple touches the floor a sound will play
                   Assets.splat.play();
                   //Increments apple counter
                   this.appleCounter++;
                   if(getAppleCounter() == 10){
                       //decrease player live
                       player.decreasePlayerLive();
                       if(player.getLives() == 0){
                           setGameOver(true);
                       }
                       //increment speed of apples
                       for(int p = 0 ; p < bads.size(); p++){
                           Bad b = bads.get(p);
                           b.incrementSpeed();
                       }
                       //set apple counter to 0
                       setAppleCounter(0);
                   }
                    //sets apple x and y position randomly
                   // bad.setY(getHeight() - 50);
                      int iPosX = (int)(Math.random() * getWidth() - 20);
                      int iPosY = (int)(Math.random() * getHeight() * 0.5d * 0.2d - 70);
                        bad.setX(iPosX);
                        bad.setY(iPosY);
                    //Subtracts score by 20
                    if(getScore() != 0){
                         decreaseScore();
                    }
                    //Every 10 apples on floor == lives -=1 and apple speed increases
               }
          }
        }
    }
    /**
     * render method
     */
    private void render() {
        // get the buffer strategy from the display
        bs = display.getCanvas().getBufferStrategy();
        /* if it is null, we define one with 3 buffers to display images of
        the game, if not null, then we display every image of the game but
        after clearing the Rectanlge, getting the graphic object from the 
        buffer strategy element. 
        show the graphic and dispose it to the trash system
        */
        if (bs == null) {
            display.getCanvas().createBufferStrategy(3);
        }
        else
        {
            g = bs.getDrawGraphics();
            //draws bg
            g.drawImage(Assets.background, 0, 0, width, height, null);
            //render the player
            player.render(g);
            //Draws the player lives
            g.drawString("Lives: " + player.getLives(), 25, 20);
            //Draws the player score
            g.drawString("Score: " + getScore(), 90, 20);
            //Draws the apple count
            g.drawString("Apple count: " + getAppleCounter(), 25, 40);
            //draws the apples
            for(int i = 0; i <bads.size();i++) {
                Bad bad = bads.get(i);
                bad.render(g);
            }
             //If gameover , draws a gameover image!
              if(isGameOver()){
                 g.drawImage(Assets.gameOver,0, 0, getWidth(), getHeight(), null);
                //render gameover
               }
            bs.show();
            g.dispose();
        }
    }
    /**
     * setting the thead for the game
     */
    public synchronized void start() {
        if (!running) {
            running = true;
            thread = new Thread(this);
            thread.start();
        }
    }
    /**
     * stopping the thread
     */
    public synchronized void stop() {
        if (running) {
            running = false;
            try {
                thread.join();
            } catch (InterruptedException ie) {
                ie.printStackTrace();
            }           
        }
    }
}