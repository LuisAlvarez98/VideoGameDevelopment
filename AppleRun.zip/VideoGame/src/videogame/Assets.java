package videogame;

import java.awt.image.BufferedImage;

/**
 * Assets Class
 * @author Luis Felipe Alvarez Sanchez A01194173
 * 12 Feb 2019
 */
public class Assets {
    public static BufferedImage background,player, apple, gameOver; // to store background, player, apple, gameover image
    public static SoundClip splat, punch; // to store sound clips

    /**
     * initializing the images of the game
     */
    public static void init() {
        background = ImageLoader.loadImage("/images/bg.png");
        player = ImageLoader.loadImage("/images/player.png");
        apple = ImageLoader.loadImage("/images/apple.png");
        splat = new SoundClip("/sounds/splat.wav");
        punch = new SoundClip("/sounds/punch.wav");
        gameOver = ImageLoader.loadImage("/images/gameover.png");
    }
    
}
