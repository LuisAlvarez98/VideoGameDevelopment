package videogame;
/**
 * VideoGame Class [Main class]
 * @author Luis Felipe Alvarez Sanchez A01194173
 * 12 Feb 2019
 */
public class VideoGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Game g = new Game("Atrapa las manzanas", 800, 500);
        g.start();
    }
    
}
